﻿using System.Windows.Forms;

namespace BetterDiscordWI.panels
{
    public partial class Panel3 : UserControl
    {
        public Panel3()
        {
            InitializeComponent();
        }
    }
}
