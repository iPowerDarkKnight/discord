## To Compile Move the DLL's folder to ``BetterDiscordWI\bin``
## Enjoy Building the Installer.