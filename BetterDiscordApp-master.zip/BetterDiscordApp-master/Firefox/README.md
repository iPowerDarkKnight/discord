#BetterDiscord
BetterDiscord enhances Discord with several features